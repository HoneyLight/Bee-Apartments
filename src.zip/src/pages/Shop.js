import Navigation from "../components/Navigation";
import ShopSection from "../components/ShopSection"
import Footer from "../components/Footer";

function Shop(){
    return(
        <div>
           <Navigation/>
          <ShopSection/>
          <Footer/>
        </div>
    );
}

export default Shop;