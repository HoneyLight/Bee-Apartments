import Navigation from "../components/Navigation";
import SingleSection1 from '../components/SingleSection1';
import Footer from "../components/Footer"


function Single(){
    return(
        <div>
            <Navigation/>
            <SingleSection1/>
            <Footer/>

        </div>
    );
}

export default Single;