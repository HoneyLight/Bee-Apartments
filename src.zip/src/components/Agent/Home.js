import Signup from "../Login&signup/Signup";

function Home(){
    return(
        <div>
            <Signup />
        </div>
    )
}

export default Home;