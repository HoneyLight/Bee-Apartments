import Footer from "../components/Footer";

function Home() {
    return(
        <div>
            <Footer/>
        </div>
    )
}

export default Home;